function moveIn() {
    document.getElementById('center-image').src="./assets/img/edgar2.png";
}

function moveOut() {
    document.getElementById('center-image').src='./assets/img/edgar.png';
}
function imageClick(){
    window.location="https://youtu.be/iik25wqIuFo";
    

}

function colorIn() {
    document.getElementById('heading').style.color='darkviolet';
}

function colorOut() {
    document.getElementById('heading').style.color='violet';
}

function toggleForm(){
    
    var status = document.getElementById('myForm').style.visibility;
    if(status==='hidden'){
        document.getElementById('myForm').style.visibility='visible';
    } else {
        document.getElementById('myForm').style.visibility='hidden';
    }
}

