<?php 
    include './assets/inc/header.php';
    include '../../dbConn.php';

    $fName = $_GET['fName'];
    $grade = $_GET['grade'];

    if(!empty($fName) && !empty($grade)){
        echo '<h2>' . $fName . ' got this much scared: ' . $grade . '</h2>';

        if($mysqli){
            $sql = "INSERT INTO Practical (fName, grade) VALUES (?, ?)";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param('si', $fName, $grade);
            $stmt->execute();
            $stmt->close();
        }


    } else {
        echo '<h2> Please go back and correct your input </h2>';
    }

    if($mysqli){
        $sql = "SELECT * FROM Practical";
        $res = $mysqli->query($sql);
        if($res){
            while ($rowHolder=$res->fetch_assoc()) {
                $records[]=$rowHolder;
            }
        }
    }

    echo '<h3> Overall results: </h3>' ;

    $total=0;
    $numOfEntries=0;
    foreach ($records as $thisRow) {
        $total +=$thisRow['grade'];
        $numOfEntries++;
        

        echo '<li>' . $thisRow['fName'] . " got scared " . $thisRow['grade'] . '</li>';

    }
    $avg = $total/$numOfEntries;
        echo '<h3> Average scare level is: '. number_format($avg, 2) . '</h3>' ;
   
?>